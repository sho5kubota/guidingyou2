<?php
/*
*================ FME Facebook Like Module =================
*===============================================
* 2013 FME Modules - http://www.fmemodules.com
*
*
*  @author Kashif Raza <razatheparagon@yahoo.com>
*  @copyright  2013 FME Modules
*  @version  1.0
*/

if (!defined('_PS_VERSION_'))
  exit;
 
class FmeFacebookLike extends Module
{
  public function __construct()
  {
    $this->name = 'fmefacebooklike';
    $this->tab = 'front_office_features';
    $this->version = 1.0;
    $this->author = 'FME Modules';
    $this->need_instance = 0;
 
    parent::__construct();
 
    $this->displayName = $this->l('FME Facebook Like');
    $this->description = $this->l('Adds a block to display a Facebook Like button on product pages.');
  }
 
 	//Install Function for Module and Hooking it to ExtraLeft
	public function install()
	{
	  if (parent::install() == false OR !$this->registerHook('extraLeft'))
		return false;
	  return true;
	}
	
	//If Uninstallation required for Module
	public function uninstall()
	{
	  if (!parent::uninstall())
		Db::getInstance()->Execute('DELETE FROM `'._DB_PREFIX_.'fmefacebooklike`');
	  parent::uninstall();
	}
	
	//Parameters For ExtraLeft Hook
	public function hookExtraLeft($params)
	{
	 global $smarty, $cookie, $link;
	  //Getting Current Product Details
	 $idProduct = Tools::getValue('id_product');
	if (isset($idProduct) && $idProduct != '')
	{		
		$dataProduct = new Product((int)$idProduct, true, $cookie->id_lang);
		$smarty->assign(array(
			'product_link' => $link->getProductLink($dataProduct),
		));
	}
		
	  return $this->display(__FILE__, 'fmefacebooklike.tpl');
	}
	
	//IF user wants to use productOutOfStock
	public function hookproductOutOfStock($params)
	{
		return $this->hookExtraLeft($params);
	}
}

?>
