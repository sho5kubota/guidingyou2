<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{fmefacebooklike}prestashop>fmefacebooklike_d28a7c047a3dfafc58ba49de75631fce'] = 'Fügt einen Block, um einen Facebook Like Button auf den Produktseiten angezeigt.';
