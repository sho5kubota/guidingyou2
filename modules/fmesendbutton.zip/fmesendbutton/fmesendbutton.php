<?php
/*
*================ FME Facebook Send Button Module =================
*===============================================
* 2013 FME Modules - http://www.fmemodules.com
*
*
*  @author Kashif Raza <razatheparagon@yahoo.com>
*  @copyright  2013 FME Modules
*  @version  1.0
*/

if (!defined('_PS_VERSION_'))
  exit;
 
class fmesendbutton extends Module
{
  public function __construct()
  {
    $this->name = 'fmesendbutton';
    $this->tab = 'front_office_features';
    $this->version = 1.0;
    $this->author = 'FME Modules';
    $this->need_instance = 1;
 
    parent::__construct();
 
    $this->displayName = $this->l('FME Facebook Send Button');
    $this->description = $this->l('Customers can send link to their Facebook friends.');
  }
 
 	//Install Function for Module and Hooking it to Footer
	public function install()
	{
		return (parent :: install() AND $this->installDb() AND $this->registerHook('displayFooter') AND $this->registerHook('extraLeft'));
	}
	
		//Make DB Tables
	public function installDb() {
		$return = true;
		$return &= Db::getInstance()->execute(' CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'fmesendbutton` (
						`site_url` varchar(255) NULL,
						 `colorscheme` int(10) unsigned NULL,
						 `font` varchar(255) NULL
							) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;');
		return $return;			
	}
	
	
	//If Uninstallation required for Module
	public function uninstall()
	{
		return ($this->uninstallDB() AND parent::uninstall());
	}
	

	 //Removing Database
	public function uninstallDB()
	{
		return (Db::getInstance()->execute('DROP TABLE IF EXISTS `'._DB_PREFIX_.'fmesendbutton`'));
	}
	
	
	//Admin Side
	public function getContent()
	{
		$html = '';
		// If Needed to Update the Settings
		if (Tools::isSubmit('submitModule'))
		{	
			Configuration::updateValue('site_url', Tools::getValue('fsb_site_url'));
			Configuration::updateValue('colorscheme', (int)Tools::getValue('fsb_colorscheme'));
			Configuration::updateValue('font', Tools::getValue('fsb_font'));
			$html .= '<div class="conf">'.$this->l('Configuration updated').'</div>';
		}
		$selected = '';
		if(Configuration::get('colorscheme') == 1){
			$selected = ' selected="selected"';
			}

		$html .= '
		<h2>'.$this->displayName.'</h2>
		<h3>'.$this->l('If you have any problem, email us at').' <font color="#0A3AEB">support@fmemodules.com</font>. </h3>
			 <h3>'.$this->l('You can visit here').' <th><a href="http://www.fmemodules.com" style="color: #0A3AEB"> www.fmemodules.com </a> </th>'.$this->l('for more modules.').' </h3>
		<form action="'.Tools::htmlentitiesutf8($_SERVER['REQUEST_URI']).'" method="post">
			<fieldset>	
			<legend><img src="../img/admin/cog.gif" />'.$this->l('Settings').'</legend>
			<label>'.$this->l('Custom URL:').'</label>
			<div class="margin-form">
			<input type="text" id="fsb_site_url" name="fsb_site_url" value="'.Configuration::get('site_url').'" /> '.$this->l(' (Optional).').'  '.$this->l(' Keep blank for auto URL.').'
			</div>
			<div class="clear">&nbsp;</div>
			<label for="flb_scheme">'.$this->l('Color Scheme:').'</label>
			<select class="fsb_colorscheme" name="fsb_colorscheme" style="width:110px">
				<option value="0">'.$this->l('Light').'</option>
				<option value="1"'.$selected.'>'.$this->l('Dark').'</option>
			</select>
			<div class="clear">&nbsp;</div>
			<label>'.$this->l('Font:').'</label>
			<div class="margin-form">
			<input type="text" id="fsb_font" name="fsb_font" value="'.Configuration::get('font').'" />  '.$this->l(' Use: arial, lucida grande, segoe ui, tahoma, trebuchet ms, verdana.').'
			</div>
			<div class="clear">&nbsp;</div>
			<div class="margin-form">
				<center><input type="submit" name="submitModule" value="'.$this->l('Save').'" class="button" /></center>
			</div>
			</fieldset>
		</form>';

		return $html;
	}
	


	
	//Hooking it to Footer
	public function hookDisplayFooter($params)
	{
		global $smarty;
		$smarty->assign(array(
			'fsb_site_url' => Configuration::get('site_url'),
			'fsb_colorscheme' => (int)Configuration::get('colorscheme'),
			'fsb_font' => Configuration::get('font'),
		));
		
		return $this->display(__FILE__, 'button.tpl');
	}
	
	//For Extra Left of Product Page
	public function hookExtraLeft($params)
	{
		global $smarty, $cookie, $link;
		$idProduct = Tools::getValue('id_product');
		$dataProduct = new Product((int)$idProduct, true, $cookie->id_lang);
		$smarty->assign(array(
			'fsb_product_link' => $link->getProductLink($dataProduct),
			'fsb_colorscheme' => (int)Configuration::get('colorscheme'),
			'fsb_font' => Configuration::get('font'),
		));
		
		return $this->display(__FILE__, 'buttonproduct.tpl');
	}
	
	//For Product Footer
	public function hookProductFooter($params)
	{
		return $this->hookExtraLeft($params);
	}
}

?>
