<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_eae1b109e864ce84ea5fc91a2dd46651'] = 'Kunden können die auf ihre Facebook-Freunde senden.';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Konfiguration aktualisiert';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_e67fbecc9bf80fb1c742434a8f049c0e'] = 'Benutzerdefinierte URL:';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_3206ea050782158d9501e980a3ffea21'] = '(fakultativ).';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_68ab370fefc151c90328fbd5d99038aa'] = 'Halten Sie für die automatische URL leer.';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_ae2169e6f3037bc9a8aa47cdfbfa908a'] = 'Farbschema:';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_9914a0ce04a7b7b6a8e39bec55064b82'] = 'Licht';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_a18366b217ebf811ad1886e4f4f865b2'] = 'Dunkel';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_7608ceca1bc61bf2307cf2772f88cd7f'] = 'Verwendung: arial, lucida grande, Segoe ui, tahoma, trebuchet ms, verdana.';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_c9cc8cce247e49bae79f15173ce97354'] = 'Sparen';
