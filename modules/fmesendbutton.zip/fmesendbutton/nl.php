<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_440d97a3c570c8fec264eb8e472a030f'] = 'FME Facebook Pagina Button';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_eae1b109e864ce84ea5fc91a2dd46651'] = 'Klanten kunnen sturen link naar hun Facebook-vrienden.';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuratie bijgewerkt';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_f4f70727dc34561dfde1a3c529b6205c'] = 'Instellingen';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_e67fbecc9bf80fb1c742434a8f049c0e'] = 'Aangepaste URL:';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_3206ea050782158d9501e980a3ffea21'] = '(Optioneel).';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_68ab370fefc151c90328fbd5d99038aa'] = 'Houd leeg voor automatische URL.';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_ae2169e6f3037bc9a8aa47cdfbfa908a'] = 'Kleurenschema:';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_9914a0ce04a7b7b6a8e39bec55064b82'] = 'Licht';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_a18366b217ebf811ad1886e4f4f865b2'] = 'Donker';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_7b33872f9b52c649fda24a8fef9492bb'] = 'Lettertype:';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_7608ceca1bc61bf2307cf2772f88cd7f'] = 'Gebruiken: arial, lucida grande, segoe ui, tahoma, trebuchet ms, verdana.';
$_MODULE['<{fmesendbutton}prestashop>fmesendbutton_c9cc8cce247e49bae79f15173ce97354'] = 'Besparen';
